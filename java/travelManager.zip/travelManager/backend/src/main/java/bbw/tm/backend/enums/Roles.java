package bbw.tm.backend.enums;

public enum Roles {
    USER,
    ADMIN
}
