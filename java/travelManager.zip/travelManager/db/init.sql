CREATE DATABASE IF NOT EXISTS travelmanager_db;
USE travelmanager_db;

-- Rollen erstellen
-- insert into role (id, name) VALUES (1, 'ADMIN') on DUPLICATE KEY UPDATE name='ADMIN';
-- insert into role (id, name) VALUES (2, 'COACH') on DUPLICATE KEY UPDATE name='COACH';
-- insert into role (id, name) VALUES (3, 'APPRENTICE') on DUPLICATE KEY UPDATE name='APPRENTICE';
